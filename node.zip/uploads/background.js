/******/ (function() { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/utils/instance.js":
/*!*******************************!*\
  !*** ./src/utils/instance.js ***!
  \*******************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
console.log('我是常量，我正式开启了哦');
// ------------ 登录接口 ----------------

// 德国仓
const LingXingErp_Login = 'https://oms.xlwms.com/gateway/woms/auth/login';
// 维赢仓 - 验证接口
const ShipoutErp_Login = 'https://oms.shipout.com/api/auth-server/oauth/token';
// 维赢仓- 登录接口
const ShipOutErp_LOGIN_FINAL = 'https://oms.shipout.com/api/wms-user/user/afterLogin';

// 派派仓- 验证码接口
const PaiPaiErp_CODE = 'https://pcpc.jfwms.net/oms/vcode';
// 派派仓- 登录接口
const PaiPaiErp_Login = 'https://pcpc.jfwms.net/oms/login';

// ------------ 登录接口 ----------------

// ------------ 库存接口 ----------------

// 德国仓-库存接口
const LingXingErp_Stock = 'https://oms.xlwms.com/gateway/woms/stock/list';

// 维赢仓-库存接口
const ShipoutErp_Stock = 'https://oms.shipout.com/api/wms-business/oms/stock/list';

// 派派仓-库存接口
const PaiPaiErp_Stock = 'https://pcpc.jfwms.net/oms/inventory/list';

// ------------ 库存接口 ----------------

// --------------- TEMU接口 ---------------

// TEMU 流量分析接口 - 功能: 监听是否有产品处于流量限制中
const TEMU_Traffic_Analysis = 'https://agentseller-us.temu.com/api/flow/analysis/list';

// --------------- TEMU接口 ---------------

// ------------ 仓库映射 ----------------

const WarehouseMap = {
  'PaiPai': '海外仓-派派仓',
  'ShipOut': '海外仓-维赢仓',
  'WeiLai': '海外仓-科隆仓'
};

// ------------ 仓库映射 ----------------

// ------------ 普通常量 ----------------

const WeiLaiToken = "weilaitoken";
const ShipoutToken = 'shipouttoken';
const PaiPaiToken = 'paipaitoken';
const PaiPai_Account = {
  "szt20171218@126.com": "7bd87f29d961ae8e129162014562de37"
};
const TEMUListenStatu = 'temulistenstatu';

// ------------ 普通常量 ----------------

// 获取网站cookie 地址
const PaiPaiURL = 'https://pcpc.jfwms.net/';

// ------------ 本地服务器接口 ----------------

const Local_URL = 'http://192.168.188.77';
const Local_PORT = '8889';
const Local_REFU_PaiPaiCODE = Local_URL + ":" + Local_PORT + '/getCode';
const Local_CALL_USER = Local_URL + ":" + Local_PORT + '/callUser';

// ------------ 本地服务器接口 ----------------

// ------------ 特殊SKU映射 ------------------

// const SpecialSkuMap = {
//     ''
// }

// ------------ 特殊SKU映射 ------------------

// ------------ 正则表达式 ----------------

const WeiLaiSkuReg = /WO-\d{2,3}-(.*)/;

// ---------------------------------------

/* harmony default export */ __webpack_exports__["default"] = ({
  PaiPaiErp_Login,
  LingXingErp_Login,
  ShipoutErp_Login,
  WarehouseMap,
  WeiLaiToken,
  ShipoutToken,
  PaiPaiToken,
  LingXingErp_Stock,
  ShipoutErp_Stock,
  PaiPaiErp_Stock,
  ShipOutErp_LOGIN_FINAL,
  WeiLaiSkuReg,
  PaiPai_Account,
  PaiPaiErp_CODE,
  Local_REFU_PaiPaiCODE,
  Local_CALL_USER,
  PaiPaiURL,
  TEMUListenStatu,
  TEMU_Traffic_Analysis
});

/***/ }),

/***/ "./src/utils/utils.js":
/*!****************************!*\
  !*** ./src/utils/utils.js ***!
  \****************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
console.log("我是工具函数, 我正式开启哦~");
/* eslint-disable */
/**
 * 网络请求函数
 * @param {String} url 网络请求地址
 * @param {String} method 网络请求方法
 * @param {Object} data 网络请求的参数
 * @param {Object} options 当是get请求的时候,通过这个传递header请求头
 * @param {String} type json | blob 两种返回格式
 * @returns Promise类型 网络请求结果
 */
async function request(url, method, data, options, type = 'json') {
  console.log(data);
  let param = null,
    keys,
    values;
  // data循环
  if (data) {
    keys = Object.keys(data);
    values = Object.values(data);
  }
  let sendUrl = url;
  if (method.toUpperCase() == 'GET') {
    if (data) {
      sendUrl = url + "?" + buildQueryString(keys, values);
    }
    param = options;
  } else {
    param = Object.assign({
      method: 'post'
    }, data);
    console.log(param);
  }
  switch (type) {
    case 'json':
      return await fetch(sendUrl, param).then(res => res.json());
    case 'blob':
      return await fetch(sendUrl, param).then(res => res.json());
    default:
      return Promise.reject('您传递的类型参数有误, 请重新输入');
  }
}
// 创建get请求携带的参数
function buildQueryString(key, value) {
  let str = [];
  for (let index = 0; index < key.length; index++) {
    const k = key[index];
    str = str.concat(`${k}=${value[index]}`);
  }
  return str.join('&');
}
// 这个是contentjs使用的 浏览器使用
class cacheWindowLocalStorage {
  constructor(prev = 'local') {
    switch (prev) {
      case 'local':
        this.type = window.localStorage;
        break;
      case 'session':
        this.type = window.sessionStorage;
        break;
      default:
        console.error('未知的存储');
    }
  }
  addLocalStorage(key, value) {
    this.type.setItem(key, value);
  }
  removeLocalStorage(key) {
    this.type.removeItem(key);
  }
  updateLocalStorage(key, value) {
    this.type.setItem(key, value);
  }
}
// 这个是node端使用的,v3之后要用storage
class cacheServiceLocalStorage {
  addLocalStorage(key, value) {
    console.log(key, value);
    chrome.storage.local.set({
      [key]: value
    }, () => {
      console.log(key, '持久化成功');
    });
  }
  async getLocalStorage(key) {
    return new Promise(resolve => {
      chrome.storage.local.get([key], result => {
        if (result[key]) {
          resolve(JSON.parse(result[key]));
        } else {
          resolve(null);
        }
        console.log(key, '获取值成功');
      });
    });
  }
  removeLocalStorage(key) {
    chrome.storage.local.remove(key, () => {
      console.log(key, '删除成功');
    });
  }
  updateLocalStorage(key, value) {
    chrome.storage.local.set({
      [key]: value
    }, () => {
      console.log(key, '更新数据成功');
    });
  }
  async existLocalStorage(key) {
    // 先拿之前的
    let value = await persistent.getLocalStorage(key);
    console.log(value);
    if (!value) {
      value = [];
    }
    return value;
  }
}

/**
 * 生成随机数 从最小值到最大值
 * @param {Number} min 最小值
 * @param {Number} max 最大值
 */
function getRandomNum(min, max) {
  return Math.ceil(Math.ceil(Math.random() * (max - min)) + min);
}

/**
 * 强制等待时间
 * @param {Number} time 等待多少秒
 * @returns 
 */
async function delayFn(time) {
  return new Promise(resolve => {
    setTimeout(() => {
      resolve();
    }, time * 1000);
  });
}
const persistent = new cacheServiceLocalStorage();
function formatDate(date = new Date(), format = 'yyyy-MM-dd HH:mm:ss') {
  // 处理传入的日期参数（支持时间戳、日期字符串、Date对象）
  if (typeof date === 'number') {
    date = new Date(date); // 时间戳转换为Date对象
  } else if (typeof date === 'string') {
    date = new Date(date.replace(/-/g, '/')); // 兼容"yyyy-MM-dd"格式字符串
  }

  // 验证日期有效性
  if (!(date instanceof Date) || isNaN(date.getTime())) {
    throw new Error('无效的日期参数');
  }

  // 提取日期各部分
  const year = date.getFullYear();
  const month = date.getMonth() + 1; // 月份从0开始，需+1
  const day = date.getDate();
  const hour = date.getHours();
  const minute = date.getMinutes();
  const second = date.getSeconds();
  const week = ['日', '一', '二', '三', '四', '五', '六'][date.getDay()];

  // 格式化映射表
  const formatMap = {
    'yyyy': year,
    // 四位年份（如：2023）
    'MM': String(month).padStart(2, '0'),
    // 两位月份（01-12）
    'M': month,
    // 一位月份（1-12）
    'dd': String(day).padStart(2, '0'),
    // 两位日期（01-31）
    'd': day,
    // 一位日期（1-31）
    'HH': String(hour).padStart(2, '0'),
    // 24小时制两位小时（00-23）
    'H': hour,
    // 24小时制一位小时（0-23）
    'hh': String(hour % 12 || 12).padStart(2, '0'),
    // 12小时制两位小时（01-12）
    'h': hour % 12 || 12,
    // 12小时制一位小时（1-12）
    'mm': String(minute).padStart(2, '0'),
    // 两位分钟（00-59）
    'm': minute,
    // 一位分钟（0-59）
    'ss': String(second).padStart(2, '0'),
    // 两位秒数（00-59）
    's': second,
    // 一位秒数（0-59）
    'w': week // 星期（日-六）
  };

  // 替换格式字符串中的占位符
  return format.replace(/yyyy|MM|M|dd|d|HH|H|hh|h|mm|m|ss|s|w/g, match => formatMap[match]);
}
/* harmony default export */ __webpack_exports__["default"] = ({
  request,
  cacheWindowLocalStorage,
  getRandomNum,
  delayFn,
  persistent,
  formatDate
});

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	!function() {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = function(exports) {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	}();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be isolated against other modules in the chunk.
!function() {
/*!********************************!*\
  !*** ./src/background/main.js ***!
  \********************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/utils/utils */ "./src/utils/utils.js");
/* harmony import */ var _utils_instance__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/utils/instance */ "./src/utils/instance.js");


let TIKTOK_BUSINESS_ACCOUNT = 'tiktokbusinessaccount';
let TIKTOK_BUSINESS_ROI_DATA = 'tiktokbusinessroidata';
let TIKTOK_BUSINESS_MS_TOKEN = 'tiktokbueinessmstoken';
// // 德国仓 - 登录
const LingXingErp_Login_GETTOKEN = async function (data) {
  let params = Object.assign(data, {
    "businessType": "oms"
  });
  return await _utils_utils__WEBPACK_IMPORTED_MODULE_0__["default"].request(Config.LingXingErp_Login, "post", {
    body: JSON.stringify(params),
    headers: {
      'content-type': 'application/json'
    }
  });
};
// 维赢仓 - outh验证
const ShipoutErp_LOGIN = async function (data) {
  console.log(data);
  let {
    loginAccount,
    password
  } = data;
  const params = new FormData();
  params.append('grant_type', 'password');
  params.append('username', loginAccount);
  params.append('password', password);
  params.append('scope', 'oms');
  params.append('systemType', 'OMS');
  params.append('client_secret', 7700);
  params.append('client_id', "browser-oms");
  return await _utils_utils__WEBPACK_IMPORTED_MODULE_0__["default"].request(Config.ShipoutErp_Login, "post", {
    body: params
  });
};
console.log('This is background page');
// // 创建一个持久化存储
// // 初始化本地的cookies
async function initCookies(url, key) {
  chrome.cookies.getAll({
    url
  }, function (cookies) {
    let str = [];
    for (let index = 0; index < cookies.length; index++) {
      const cookie = cookies[index];
      str = str.concat(`${cookie.name}=${cookie.value}`);
    }
    // 存储起来
    _utils_utils__WEBPACK_IMPORTED_MODULE_0__["default"].persistent.addLocalStorage(key, JSON.stringify(str.join(';')));
  });
}

// 向当前的激活tab发送
async function toActivePage(message, data) {
  chrome.tabs.query({
    active: true,
    currentWindow: true
  }, function (tabs) {
    let tab = tabs[0];
    if (tab) {
      // 将数据传递出去
      chrome.tabs.sendMessage(tab.id, {
        message,
        data
      });
    } else {
      console.log('当前没有chrome在线');
    }
  });
}

// // 得到baseurl
chrome.runtime.onMessage.addListener(async (params, sender, sendResponse) => {
  sendResponse({
    'statu': 'pending'
  });
  // 这个地方 接受popup.html发送过来的内容
  if (params.message === 'addWarehouse') {
    // 当前添加的是什么仓库 有 weiying paipai weilai
    let resp;
    let type = params.data.Erp;
    let info = params.data.Info;
    console.log(info, type);
    let prev;
    switch (type) {
      case 'PaiPai':
        break;
      case 'ShipOut':
        resp = await ShipoutErp_LOGIN(info);
        if (resp.access_token.length) {
          // 先拿之前的
          prev = await _utils_utils__WEBPACK_IMPORTED_MODULE_0__["default"].persistent.existLocalStorage(_utils_instance__WEBPACK_IMPORTED_MODULE_1__["default"].ShipoutToken);
          // // 加进去
          prev = prev.concat({
            account: info.loginAccount,
            pwd: info.password,
            token: resp.access_token
          });
          // 有值,存起来token
          _utils_utils__WEBPACK_IMPORTED_MODULE_0__["default"].persistent.addLocalStorage(_utils_instance__WEBPACK_IMPORTED_MODULE_1__["default"].ShipoutToken, JSON.stringify(prev));
          chrome.runtime.sendMessage({
            message: 'addSuccess'
          });
        }
        // 请求维赢的数据
        break;
      case 'WeiLai':
        resp = await LingXingErp_Login_GETTOKEN(info);
        if (resp.code === 200) {
          // 先拿之前的
          prev = await _utils_utils__WEBPACK_IMPORTED_MODULE_0__["default"].persistent.existLocalStorage(_utils_instance__WEBPACK_IMPORTED_MODULE_1__["default"].WeiLaiToken);
          // 加进去
          prev = prev.concat({
            account: info.loginAccount,
            pwd: info.password,
            token: resp.data.token
          });
          // 成功啦 存储token
          _utils_utils__WEBPACK_IMPORTED_MODULE_0__["default"].persistent.addLocalStorage(_utils_instance__WEBPACK_IMPORTED_MODULE_1__["default"].WeiLaiToken, JSON.stringify(prev));
          chrome.runtime.sendMessage({
            message: 'addSuccess'
          });
        }
        break;
      default:
        // 未知的账号
        throw new Error('出现了未知的错误');
    }
  } else if (params.message === 'cookies') {
    console.log('触发了');
    initCookies(params.data.url, params.data.name);
  } else if (params.message === 'good_limit') {
    // data是true就是监听 false就是不监听
    let resp,
      isLimit = false,
      isRun = params.statu,
      sendData = {},
      listenData = [],
      haveLimitData = [],
      alreadyAdd = false;
    if (params.statu) {
      // 请求数据 如果我是有传递的,就传参数给LIMIT
      if (params.data[0].trim()) {
        sendData = {
          productSkcIdList: params.data
        };
      }
      let param = Object.assign({
        "pageSize": 30,
        "pageNumber": 1,
        "timeDimension": 1
      }, sendData);
      while (isRun) {
        let mallid = await _utils_utils__WEBPACK_IMPORTED_MODULE_0__["default"].persistent.getLocalStorage('temu_mallid');
        resp = await _utils_utils__WEBPACK_IMPORTED_MODULE_0__["default"].request(_utils_instance__WEBPACK_IMPORTED_MODULE_1__["default"].TEMU_Traffic_Analysis, "post", {
          body: JSON.stringify(param),
          headers: {
            'content-type': 'application/json',
            'Mallid': mallid
          }
        });
        // 判断是否有被禁的
        if (resp.success) {
          for (let i = 0; i < resp.result.pageItems.length; i++) {
            if (resp.result.pageItems[i].flowLimitStatus === 2) {
              haveLimitData = haveLimitData.concat({
                id: resp.result.pageItems[i].productId,
                statu: 2
              });
            }
            if (!alreadyAdd) {
              listenData = listenData.concat({
                id: resp.result.pageItems[i].productId,
                statu: 1
              });
            }
          }
        }
        // 如果有,就要去操作了 操作完事就停止了
        if (haveLimitData.length) {
          // 发请求
          resp = await _utils_utils__WEBPACK_IMPORTED_MODULE_0__["default"].request(_utils_instance__WEBPACK_IMPORTED_MODULE_1__["default"].Local_CALL_USER, "get");
          isRun = false;
          chrome.runtime.sendMessage({
            message: 'listenData',
            data: listenData,
            errorData: haveLimitData
          });
        } else {
          // 没有
          chrome.runtime.sendMessage({
            message: 'listenData',
            data: listenData
          });
        }
        alreadyAdd = true;
        await _utils_utils__WEBPACK_IMPORTED_MODULE_0__["default"].delayFn(300);
      }
    } else {
      isRun = false;
    }
  } else if (params.message === 'temu_rate_mallid') {
    // 存储起来
    _utils_utils__WEBPACK_IMPORTED_MODULE_0__["default"].persistent.addLocalStorage('temu_mallid', params.data);
  } else if (params.message === 'listenTk') {
    // 业务函数外接
    await get_TikTok_Data();
    // 一小时出来一次
    timer = setInterval(() => {
      get_TikTok_Data();
    }, 1000 * 60 * 60);
  } else if (params.message === 'gettiktokmsToken') {
    _utils_utils__WEBPACK_IMPORTED_MODULE_0__["default"].persistent.addLocalStorage(TIKTOK_BUSINESS_MS_TOKEN, params.data);
  }
});

// 强制顶戴上一次函数的执行完成再执行当前的函数
function strongWait(fn) {}

// tiktok 申请所有的数据
const get_TikTok_Data = async function () {
  let roi_data = {},
    showStr = '',
    moneyStr = '';
  let account_url = 'https://business.tiktok.com/api/v3/bm/account/list/?org_id=7490498299846361105&attr_source=&source_biz_id=&attr_type=web&page=1&keyword=&account_type=1&limit=10';
  // 先看看本地有没有存储,有的话就不用再请求一次了
  let local_account = await _utils_utils__WEBPACK_IMPORTED_MODULE_0__["default"].persistent.getLocalStorage(TIKTOK_BUSINESS_ACCOUNT);
  // 拿到所有的账目  
  if (!local_account) {
    let resp = await _utils_utils__WEBPACK_IMPORTED_MODULE_0__["default"].request(account_url, "get");
    if (resp.msg === 'success') {
      // 持久化保存下
      console.log('看看我的账户', resp.data);
      _utils_utils__WEBPACK_IMPORTED_MODULE_0__["default"].persistent.addLocalStorage(TIKTOK_BUSINESS_ACCOUNT, JSON.stringify(resp.data.accounts));
      local_account = resp.data.accounts;
    } else {
      console.log('报错是:', resp);
    }
  }
  // 接下去往下走 拿到所有的账户的广告数据,保存在本地
  // 拿到今天的数据
  let today = _utils_utils__WEBPACK_IMPORTED_MODULE_0__["default"].formatDate(new Date(), "yyyy-MM-dd");
  let url = 'https://ads.tiktok.com/api/v3/i18n/statistics/transaction/balance/query/';
  let bec_seller_url = "https://business.tiktok.com/api/v3/bm/account/gmv_max/?org_id=7490498299846361105&attr_source=&source_biz_id=&attr_type=web&account_type=1";
  let roi_url = "https://ads.tiktok.com/api/oec_shopping/v1/oec/stat/post_overview_stat?locale=zh&language=zh&bc_id=7490498299846361105";
  let msToken = await _utils_utils__WEBPACK_IMPORTED_MODULE_0__["default"].persistent.getLocalStorage(TIKTOK_BUSINESS_MS_TOKEN);
  // 拿到当前选择的广告户的数据
  for (let index = 0; index < local_account.length; index++) {
    const account = local_account[index];
    let filter_list = ['YG', 'MQ'];
    let listen_item = filter_list.find(item => account.account_name.includes(item));
    let country_en = account.account_name.substring(0, 5);
    let currentCNmoney = null;
    if (account.account_name.includes('MQ')) {
      // 要用昨天
      today = _utils_utils__WEBPACK_IMPORTED_MODULE_0__["default"].formatDate(new Date(new Date().getTime() - 86400000), "yyyy-MM-dd");
    }
    // 在这里请求我的金额额度
    let money_url = url;
    const response = await _utils_utils__WEBPACK_IMPORTED_MODULE_0__["default"].request(money_url, "get", {
      aadvid: account.account_id,
      source: 3,
      req_src: 'bidding',
      msToken
    });
    if (response.msg === 'success') {
      currentCNmoney = `${country_en}当前通用额度: ${response.data?.credit_cash_valid}USD, 广告可用额度： ${response.data?.ad_credit_valid}USD\n`;
      moneyStr += currentCNmoney;
    } else {
      console.log('有大问题~');
    }
    if (!listen_item) {
      continue;
    }
    console.log(listen_item);
    // 这个是拿到oec_seller_id用的
    bec_seller_url += `&account_id=${account.account_id}&shop_owner_id=${account.owner_id}`;
    let resp = await _utils_utils__WEBPACK_IMPORTED_MODULE_0__["default"].request(bec_seller_url, "get");
    if (resp.msg === 'success') {
      // https://ads.tiktok.com/api/oec_shopping/v1/oec/stat/post_campaign_list?locale=zh&language=zh&oec_seller_id=8647042004561596131&aadvid=7527560980491026440&bc_id=7490498299846361105
      // 这个是拿到当前的所有广告计划的 然后campaign_opt_status等于1是关闭,等于0是开启 暂时先不用
      // 证明拿到了id值,可以开始去拿roi数据了
      let aaid = resp.data.accounts[0].account_id;
      // 这个是拿到每个广告的roi
      roi_url += `&oec_seller_id=${aaid}&aadvid=${account.account_id}`;
      resp = await _utils_utils__WEBPACK_IMPORTED_MODULE_0__["default"].request(roi_url, "post", {
        body: JSON.stringify({
          "query_list": ["cost", "onsite_roi2_shopping_sku", "cost_per_onsite_roi2_shopping_sku", "onsite_roi2_shopping_value", "onsite_roi2_shopping"],
          "start_time": today,
          "end_time": today,
          "campaign_shop_automation_type": 2,
          "external_type_list": ["307", "304", "305"]
        }),
        headers: {
          'content-type': 'application/json'
        }
      });
      if (resp.data?.statistics) {
        // 证明就是拿到数据了
        let data = resp.data.statistics;
        let cost = data.cost; // 消费成本
        let spend_rate = data.onsite_roi2_shopping; // 投资回报率
        let get_order = data.onsite_roi2_shopping_sku; // 出的单量
        let all_sell = data.onsite_roi2_shopping_value; // 总收入
        let sell_rate = data.cost_per_onsite_roi2_shopping_sku; // 平均下单的成本 也就是roi
        showStr += `${country_en}当前每单消耗: ${sell_rate}USD, 现已消耗了${cost}USD, 出了${get_order}单\n`;
        roi_data[country_en] = {
          cost,
          spend_rate,
          get_order,
          all_sell,
          sell_rate,
          currentMoney: currentCNmoney
        };
      }
    }
    await _utils_utils__WEBPACK_IMPORTED_MODULE_0__["default"].delayFn(2);
  }
  // 保存到本地
  _utils_utils__WEBPACK_IMPORTED_MODULE_0__["default"].persistent.addLocalStorage(TIKTOK_BUSINESS_ROI_DATA, JSON.stringify(roi_data));
  // 触发弹窗
  // let id = new Date().getTime() + ''
  // 改变策略， 直接给页面，页面去传递就行了
  toActivePage('tiktokCurrentBusiness', {
    roiData: showStr,
    moneyData: moneyStr
  });
  // chrome.notifications.create(id,{
  //     type: 'basic',
  //     title: '广告提醒',
  //     iconUrl: chrome.runtime.getURL("/assets/icon.png"),
  //     message: showStr
  // }, (notificationId) => {
  //     if (chrome.runtime.lastError) {
  //         console.error('创建通知失败:', chrome.runtime.lastError.message);
  //     } else {
  //         console.log('通知创建成功，ID:', notificationId);
  //     }
  // })
};
}();
/******/ })()
;
//# sourceMappingURL=background.js.map